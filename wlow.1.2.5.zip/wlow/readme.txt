-------------------------------------------------------
    Thank you for downloading Wlow Theme!
-------------------------------------------------------
This and any other Theme provided by MarchettiDesign should
be free of bugs, however do note that we're only humans
and if you spot a bug do us a favor and report here
http://www.marchettidesign.net/contatti/

-------------------------------------------------------
   Installation:
-------------------------------------------------------


To install the theme correctly follow the Official Video Documentation:
http://www.marchettidesign.net/wlow/docs.html


-------------------------------------------------------
    Features:
-------------------------------------------------------

- Widgets
Wlow has one sidebar on the right.

- Page Templates
Wlow has a home page template with Sections and Parllax

We Have:
Blog Layout, Category, Tag & Search Layout,

- Menus
One menu on the top.


-------------------------------------------------------
    Framework:
-------------------------------------------------------

Wlow use bootstrap grid, menu and slider, also use font awesome for the icons.


-------------------------------------------------------
    License:
-------------------------------------------------------


Wlow WordPress theme, Copyright (C) 2016 MarchettiDesign
Wlow WordPress theme is licensed under the GPL.

Twitter Bootstrap - http://getbootstrap.com/
License: Distributed under the terms of the Apache License v2.0
Copyright: Twitter, http://twitter.com

Font Awesome - http://fontawesome.io
License: Distributed under the terms of the SIL OFL License 1.1 (fonts), MIT License (code), and CC BY 3.0 License (documentation)
Copyright: Font Awesome, http://fontawesome.io

Magnific Popup - http://dimsemenov.com/plugins/magnific-popup/
License: Distributed under MIT license (MIT)
Copyright: 2014-2016 Dmitry Semenov, http://dimsemenov.com

Html5Shiv - https://github.com/aFarkas/html5shiv
License:  Distributed under a dual license system (MIT or GPL version 2)
Copyright: 2014 Alexander Farkas (aFarkas).

Respond - https://github.com/scottjehl/Respond
License: Distributed under MIT license (MIT)
Copyright: Copyright (c) 2012 Scott Jehl

jQuery Mobile Touch - https://jquerymobile.com/
License: Distributed under MIT license (MIT)
Copyright: Copyright 2010, 2013 jQuery Foundation

Wlow uses a modified version of Edward McIntyre’s wp_boot_strap_navwalker  - https://github.com/twittem/wp-bootstrap-navwalker
License: GPL-2.0+
Copyright: Edward McIntyre - @twittem


Demo Images	- https://unsplash.com/
License: All unsplash.com images are licensed under the terms of the Creative Commons Zero, http://creativecommons.org/publicdomain/zero/1.0/

* img/demo/city.png
Source: https://unsplash.com/photos/8VjYSSZDogU

Everything else used in this theme (including the screenshot.png) has been created by me (Andrea Marchetti), especially for the Wlow theme and is distributed under GPL v3 license.


-------------------------------------------------------
    Adopting Wlow Theme (Theme Re-Distribution):
-------------------------------------------------------

It's GPL so yes you can base your Themes from Wlow
please note that if you do the GPLv3 License needs to stay
as well as all copyright notices included in all parts of
this Theme.
