jQuery(document).ready(function() {

		/* Upsells in customizer (Documentation link and Upgrade to PRO link */
		jQuery('#customize-info').css({'border':'none'})
		jQuery('#customize-info').append('<ul><li><a style="width: 80%; margin: 5px auto 5px auto; display: block; text-align: center;" href="http://www.marchettidesign.net/wlow/docs.html" class="button" target="_blank">Documentation</a> </li></ul>');
	  jQuery('#customize-info .preview-notice').append('<a style="background:#ff3b60;color:#fff;padding:0px 10px;margin-top:10px;display:inline-block;font-size:10px;text-transform:uppercase;text-decoration:none;" href="http://www.marchettidesign.net/wlow/#premium" target="_blank" class="view-pro-version">View Premium Version</a>');

});
